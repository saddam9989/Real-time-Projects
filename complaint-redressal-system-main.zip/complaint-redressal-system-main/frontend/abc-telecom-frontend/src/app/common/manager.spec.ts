import { Manager } from './manager';

describe('Manager', () => {
  it('should create an instance', () => {
    expect(new Manager()).toBeTruthy();
  });
});
