export class Zipcode {
    
    zipcode:string;
}
