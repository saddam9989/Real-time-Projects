export class UserDto {
}
