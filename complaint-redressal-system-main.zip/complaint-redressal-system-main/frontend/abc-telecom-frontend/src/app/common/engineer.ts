import { User } from "./user";

export class Engineer {
    id:number;
    user:User;
    zipcode:string;
}
