import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ticket-edit',
  templateUrl: './ticket-edit.component.html',
  styleUrls: ['./ticket-edit.component.css']
})
export class TicketEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
